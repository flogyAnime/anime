document.getElementsByClassName("home_")[0].classList.add("this"),document.getElementsByClassName("home_")[1].classList.add("this");
//# sourceMappingURL=../../maps/js/main.js.b7a7259f0184.map
