document.getElementsByClassName("anime_list_")[0].classList.add("this"),document.getElementsByClassName("anime_list_")[1].classList.add("this");
//# sourceMappingURL=../../maps/js/main.js.b7a7259f0184.map
